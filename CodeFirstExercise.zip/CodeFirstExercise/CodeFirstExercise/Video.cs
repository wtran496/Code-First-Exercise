namespace CodeFirstExercise
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Video
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public DateTime ReleaseDate { get; set; }

        public byte? Genres_Id { get; set; }

        public int Classifications { get; set; }

        public virtual Genre Genre { get; set; }
    }
}
