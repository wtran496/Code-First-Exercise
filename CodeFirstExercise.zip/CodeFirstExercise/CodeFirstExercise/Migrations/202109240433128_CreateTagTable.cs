namespace CodeFirstExercise.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateTagTable : DbMigration
    {
        public override void Up()
        {
            //Create Tag Table
            CreateTable(
                "dbo.Tags",
                c => new
                {
                    Id = c.Int(nullable: false, identity: true),
                    Name = c.String(),
                })
                .PrimaryKey(t => t.Id);

            //Create Linkage Table
            CreateTable(
               "dbo.VideoTags",
               c => new
               {
                   VideoId = c.Int(nullable: false),
                   TagId = c.Int(nullable: false),
               })
                .PrimaryKey(t => new { t.VideoId, t.TagId })
                .Index(t => t.VideoId)
                .Index(t => t.TagId);
            AddForeignKey("dbo.VideoTags", "VideoId", "dbo.Videos", "Id");
            AddForeignKey("dbo.VideoTags", "TagId", "dbo.Tags", "Id");
        }

        public override void Down()
        {
            DropForeignKey("dbo.VideoTags", "TagId", "dbo.Tags");
            DropForeignKey("dbo.VideoTags", "VideoId", "dbo.Videos");
            DropIndex("dbo.VideoTags", new[] { "TagId" });
            DropIndex("dbo.VideoTags", new[] { "VideoId" });
            DropTable("dbo.VideoTags");
            DropTable("dbo.Tags");
        }


    }
}
