namespace CodeFirstExercise.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class VidOnetoMany : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Videos", "Genres_Id", c => c.Byte());
            CreateIndex("dbo.Videos", "Genres_Id");
            AddForeignKey("dbo.Videos", "Genres_Id", "dbo.Genres", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Videos", "Genres_Id", "dbo.Genres");
            DropIndex("dbo.Videos", new[] { "Genres_Id" });
            DropColumn("dbo.Videos", "Genres_Id");
        }
    }
}
