namespace CodeFirstExercise.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class GenreDummyData : DbMigration
    {
        public override void Up()
        {
            Sql(@" INSERT INTO Genres (Id, Name) VALUES 
	            (1, 'Mystery'), 
	            (2, 'Suspense'), 
	            (3, 'Horror')
            ");
        }

        public override void Down()
        {
            Sql("DELETE FROM Genres WHERE Id BETWEEN 1 AND 3");
        }
    }
}
