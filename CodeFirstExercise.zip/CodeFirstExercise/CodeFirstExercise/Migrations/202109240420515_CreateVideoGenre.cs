namespace CodeFirstExercise.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateVideoGenre : DbMigration
    {
        public override void Up()
        {
            CreateTable(
            "dbo.VideoGenres",
            c => new
            {
                Video_Id = c.Int(nullable: false),
                Genre_Id = c.Byte(nullable: false),
            })
            .PrimaryKey(t => new { t.Video_Id, t.Genre_Id })
            .Index(t => t.Video_Id)
            .Index(t => t.Genre_Id);
            AddForeignKey("dbo.VideoGenres", "Video_Id", "dbo.Videos", "Id");
            AddForeignKey("dbo.VideoGenres", "Genre_Id", "dbo.Genres", "Id");

        }
        
        public override void Down()
        {
            DropForeignKey("dbo.VideoGenres", "Genre_Id", "dbo.Genres");
            DropForeignKey("dbo.VideoGenres", "Video_Id", "dbo.Videos");
            DropIndex("dbo.VideoGenres", new[] { "Genre_Id" });
            DropIndex("dbo.VideoGenres", new[] { "Video_Id" });
            DropTable("dbo.VideoGenres");
        }
    }
}
