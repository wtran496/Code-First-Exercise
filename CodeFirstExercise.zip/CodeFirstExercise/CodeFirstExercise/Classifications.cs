﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstExercise
{
    class Classifications
    {
        public enum Classification : byte
        {
            Silver = 1,
            Gold = 2,
            Platinum = 3,
        }
    }
}
